# AI-Driven Reconfigurable Antenna System for 5G Communication

A final-year, GitHub-ready project that uses **Machine Learning** to **auto-tune** a reconfigurable antenna for 5G bands.
The system learns the best antenna **state** (e.g., PIN diode/varactor settings or RF switch positions) to maximize
link quality metrics such as **RSSI, RSRP, SINR, throughput**, or minimize **|S11|**.

---

## ✨ Key Features
- Modular repo (antenna design, data, ML, controller).
- Supervised ML baseline + Bayesian optimization tuner.
- Ready-to-run Python training script and evaluation.
- Hardware-optional: works with **simulated** or **measured** datasets.
- MIT-licensed and production-friendly structure.

---

## 🧱 System Overview

```text
Reconfigurable Antenna  ←→  Microcontroller (switch control)
        ↓                               ↑
    SDR / RF Meter  →→  Metrics (RSSI, SINR, S11)
        ↓
     Python ML  →→  Predict/Optimize best antenna state
        ↓
    Controller  →→  Apply state and log performance
```

---

## 📂 Repository Structure
```text
5G-Reconfigurable-Antenna-AI/
├── antenna_design/        # CST/HFSS/FEKO exports, images
├── data/                  # CSV/Parquet logs (simulated or measured)
├── ml_model/              # ML training & optimization code
├── controller_code/       # Arduino / ESP32 / Raspberry Pi scripts
├── results/               # Plots, reports
├── .github/workflows/     # CI (optional)
├── requirements.txt
├── LICENSE
└── README.md
```

---

## 🗃️ Data Format (CSV)
Save your measurements/sim outputs in `data/measurements.csv` with columns like:
```csv
freq_hz,temperature_c,env_id,probe_rssi_dbm,probe_sinr_db,prev_state,best_state,throughput_mbps,s11_db
3.5e9,30,0,-68,18,12,21,87.2,-14.3
```
- **freq_hz**: Operating frequency (e.g., 3.5e9).
- **probe_rssi_dbm / probe_sinr_db**: Small number of pilot probes or sensor hints.
- **prev_state**: Last antenna config integer (e.g., 0–63).
- **best_state**: Ground-truth best state for that condition (classification label).
- **throughput_mbps / s11_db**: Optional targets for regression/validation.

> If you don’t have hardware, generate a **synthetic dataset** with `ml_model/generate_synth_data.py` and start.

---

## 🚀 Quickstart
```bash
# 1) Create & activate a virtual environment (optional)
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\Scripts\activate

# 2) Install dependencies
pip install -r requirements.txt

# 3) (Optional) Generate synthetic data
python ml_model/generate_synth_data.py --rows 2000 --states 64 --freq 3.5e9

# 4) Train baseline model
python ml_model/train.py --data data/measurements.csv --task classify --states 64

# 5) Run Bayesian tuner demo
python ml_model/bo_tuner.py --states 64
```

---

## 📈 What to Show in Your Report
- Confusion matrix / Top-1 accuracy for **best_state** prediction.
- Throughput/BLER/SINR improvements vs baseline fixed state.
- |S11| and bandwidth plots before/after tuning (if available).
- Ablation: with/without temperature, number of probes, etc.

---

## 🧪 Hardware Notes (Optional)
- Use **PIN diodes / RF switches** for discrete states; **varactors** for analog tuning.
- Control via **Arduino/ESP32/Raspberry Pi** (GPIO). Communicate with Python over serial.
- Measure with **SDR** (Pluto/RTL-SDR/HackRF) or RF meter; or import S-parameters from EM simulation.

---

## 📜 License
MIT — see `LICENSE`. Feel free to use in academic or industry demos.

---

## 🙌 Credits
Starter template generated for a final-year project focusing on **AI + 5G Reconfigurable Antennas**.
