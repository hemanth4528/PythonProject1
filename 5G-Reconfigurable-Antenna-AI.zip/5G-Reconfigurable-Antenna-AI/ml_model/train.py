import argparse, pandas as pd, numpy as np
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, classification_report, mean_absolute_error
from sklearn.ensemble import RandomForestClassifier, RandomForestRegressor
import joblib, os

parser = argparse.ArgumentParser()
parser.add_argument('--data', type=str, default='data/measurements.csv')
parser.add_argument('--task', type=str, choices=['classify','regress'], default='classify')
parser.add_argument('--states', type=int, default=64)
parser.add_argument('--model_out', type=str, default='ml_model/model.joblib')
args = parser.parse_args()

df = pd.read_csv(args.data)

feature_cols = ['freq_hz','temperature_c','env_id','probe_rssi_dbm','probe_sinr_db','prev_state']
X = df[feature_cols]
if args.task == 'classify':
    y = df['best_state'].astype(int)
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
    model = RandomForestClassifier(n_estimators=250, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    acc = accuracy_score(y_test, pred)
    print(f'Accuracy: {acc:.3f}')
    print(classification_report(y_test, pred, digits=3))
else:
    y = df['throughput_mbps']
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    model = RandomForestRegressor(n_estimators=300, random_state=42, n_jobs=-1)
    model.fit(X_train, y_train)
    pred = model.predict(X_test)
    mae = mean_absolute_error(y_test, pred)
    print(f'MAE: {mae:.3f} Mbps')

os.makedirs(os.path.dirname(args.model_out), exist_ok=True)
joblib.dump(model, args.model_out)
print('Saved model ->', args.model_out)
