import argparse, numpy as np, pandas as pd

parser = argparse.ArgumentParser()
parser.add_argument('--rows', type=int, default=2000)
parser.add_argument('--states', type=int, default=64)
parser.add_argument('--freq', type=float, default=3.5e9)
parser.add_argument('--out', type=str, default='data/measurements.csv')
args = parser.parse_args()

rng = np.random.default_rng(42)

freq_hz = np.full(args.rows, args.freq)
temperature_c = rng.normal(30, 5, size=args.rows).round(2)
env_id = rng.integers(0, 4, size=args.rows)  # 0-indoor,1-outdoor,2-line-of-sight,3-blocked
prev_state = rng.integers(0, args.states, size=args.rows)

# Hidden "true" best state per env and temperature drift
env_bias = rng.integers(0, args.states, size=4)
base_best = (env_bias[env_id] + (temperature_c // 5).astype(int)) % args.states
noise = rng.integers(-2, 3, size=args.rows)  # small variability
best_state = (base_best + noise) % args.states

# Probing signals loosely correlated with proximity to best_state
delta = np.abs(prev_state - best_state)
probe_rssi_dbm = -70 - delta*0.5 + rng.normal(0, 1.0, size=args.rows)
probe_sinr_db = 18 - delta*0.3 + rng.normal(0, 0.7, size=args.rows)

# Optional targets
throughput_mbps = 80 + (20 - delta*1.2) + rng.normal(0, 2.0, size=args.rows)
s11_db = -10 - (5 - np.minimum(delta, 5))*0.8 + rng.normal(0, 0.5, size=args.rows)

df = pd.DataFrame({
    'freq_hz': freq_hz,
    'temperature_c': temperature_c,
    'env_id': env_id,
    'probe_rssi_dbm': probe_rssi_dbm.round(2),
    'probe_sinr_db': probe_sinr_db.round(2),
    'prev_state': prev_state,
    'best_state': best_state.astype(int),
    'throughput_mbps': throughput_mbps.round(2),
    's11_db': s11_db.round(2),
})

df.to_csv(args.out, index=False)
print(f'Wrote {len(df)} rows -> {args.out}')
