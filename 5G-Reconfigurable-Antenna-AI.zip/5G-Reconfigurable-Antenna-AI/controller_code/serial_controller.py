# Example serial controller to send antenna state to a microcontroller.
# Replace 'COM3' with your port; microcontroller should listen for lines like: STATE 21
import time, serial, argparse

parser = argparse.ArgumentParser()
parser.add_argument('--port', type=str, default='COM3')  # Linux: /dev/ttyUSB0
parser.add_argument('--baud', type=int, default=115200)
parser.add_argument('--state', type=int, default=21)
args = parser.parse_args()

with serial.Serial(args.port, args.baud, timeout=2) as ser:
    cmd = f'STATE {args.state}\n'.encode()
    ser.write(cmd)
    time.sleep(0.1)
    print('Sent:', cmd.decode().strip())
    resp = ser.readline().decode(errors='ignore').strip()
    if resp:
        print('MCU:', resp)
